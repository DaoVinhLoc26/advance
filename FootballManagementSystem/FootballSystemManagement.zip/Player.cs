﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FootballManagementSystem
{

    internal class Player : IPlayer
    {

        public string Name;
        public int Age;
        public int attack;
        public int defense;
        public int stamina;
        public int speed;
        public int power;
    }

}


